# MedAware AI Healthcare Platform

Premium medicine/product awareness website with a real backend AI architecture.

## What is included

- Premium responsive frontend
- Medicine catalogue
- Medicine detail modal
- Disease/condition catalogue
- Multilingual AI chat architecture
- Live medical-source retrieval through Tavily (authoritative-domain allowlist)
- OpenAI backend integration
- Source cards
- Rate limiting + Helmet + CORS
- Environment variables
- Founder mailto CTA
- No cart/checkout/payment

## Setup

1. Install Node.js 20+.
2. In the project root run:

```bash
npm install
```

3. Copy `.env.example` to `.env`.
4. Add:

```env
OPENAI_API_KEY=your_key
TAVILY_API_KEY=your_tavily_key
OPENAI_MODEL=gpt-5
FOUNDER_EMAIL=your-real-email@example.com
```

5. Run:

```bash
npm start
```

Open http://localhost:5000

## AI retrieval

The AI endpoint is `/api/ai/chat`.

Flow:

User query -> local catalogue context -> authoritative-domain search -> LLM -> cited response.

The retrieval service currently restricts searches to WHO, NHS, MedlinePlus, FDA and PubMed domains. Extend the allowlist only after reviewing a source's reliability and licensing.

## Important

The included image URLs are demonstration references and should be replaced with official/licensed product imagery before production. The catalogue does not contain live prices by default.

Medical information is educational. It is not diagnosis or individualized medical advice.

## Production

Deploy the Node backend on a service such as Render/Railway/VPS and configure the same environment variables. Keep API keys only on the server.

For a production catalogue, replace the JSON files with a reviewed database and an admin workflow. Every medicine record should have source and last-verified metadata.

## Founder email

Change `FOUNDER_EMAIL` in `.env` and update the frontend configuration if you want the static CTA to use the same value. A production version should inject this value from a safe configuration endpoint rather than exposing other private configuration.


## v2 changes
- 15 conditions with English/Hindi/Hinglish/Marathi content and exact basic-advice sections.
- Language switch updates the interface, catalogue condition names, disease details, and AI response language.
- English mode never requests Hinglish/Hindi/Marathi output; Hinglish is only used when selected.
- 12 medicine entries with richer safety/use details and guaranteed local illustrative images.
- AI has a local catalogue fallback so known medicine/condition questions work even before an OpenAI key is configured; adding `OPENAI_API_KEY` enables live AI + retrieval.
- Added reveal, hover and ambient animations.


## v3 fixes
- Bundled local PNG medicine illustrations so catalogue images do not depend on remote URLs.
- Fixed medicine View details and disease Learn more buttons under Helmet CSP by using delegated event handlers.
- Improved AI matching so disease queries such as Fever and Stomach Pain resolve to their own disease records instead of a generic pain medicine match.

## Medicine images (v4)
The 12 medicine card/detail images are the exact image assets extracted from the user-provided `11802.pdf` (one medicine per page). They are bundled locally under `frontend/assets/medicines/`, so the website does not depend on external image URLs.
