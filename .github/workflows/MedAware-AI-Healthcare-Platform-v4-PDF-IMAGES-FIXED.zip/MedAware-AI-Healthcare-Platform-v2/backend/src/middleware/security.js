const rateLimit = require('express-rate-limit');
const limiter = rateLimit({windowMs: 60*1000, max: 30, standardHeaders: true, legacyHeaders: false});
module.exports = { limiter };
