const express=require('express');
const medicines=require('../data/medicines.json');
const diseases=require('../data/diseases.json');
const {answer}=require('../services/ai');
const {searchMedicalSources}=require('../services/search');
const router=express.Router();

const norm=s=>String(s||'').toLowerCase().trim();
const langMap={English:'en','हिन्दी':'hi','Hinglish':'hinglish','मराठी':'mr',en:'en',hi:'hi',hinglish:'hinglish',mr:'mr'};
function matchItem(q){
  const n=norm(q);
  const all=[...medicines.map(x=>({...x,type:'medicine'})),...diseases.map(x=>({...x,type:'disease'}))];
  if(!n) return null;

  const wantsMedicine=/\b(medicine|medicines|tablet|tablets|capsule|capsules|drug|drugs|dose|dosage|side effect|side effects|brand|composition|generic)\b/i.test(n);
  const wantsCondition=/\b(disease|condition|symptom|symptoms|sign|signs|what is|what are|advice|treatment|problem|pain|fever|cough|cold|diabetes|dengue|malaria|asthma|cancer|tb|tuberculosis|copd|kidney|heart|blood pressure)\b/i.test(n);

  const scored=all.map(x=>{
    const name=norm(x.name), aliases=(x.aliases||[]).map(norm), generic=norm(x.generic_name);
    const fields=[
      ...aliases.map(v=>({v,w:7})),
      {v:name,w:10},
      {v:generic,w:x.type==='medicine'?6:0},
      ...(x.conditions||[]).map(v=>({v:norm(v),w:4})),
      ...(x.uses||[]).map(v=>({v:norm(v),w:2})),
      ...(x.symptoms||[]).map(v=>({v:norm(v),w:3}))
    ];
    let score=0;
    for(const f of fields){
      if(f.v && n.includes(f.v)) score+=f.w;
      const words=f.v.split(/\s+/).filter(w=>w.length>2);
      const matched=words.filter(w=>n.includes(w)).length;
      score += matched * (f.w===10?2:f.w===7?1.5:1);
    }
    if(x.type==='medicine' && wantsMedicine) score+=8;
    if(x.type==='disease' && wantsCondition) score+=8;
    if(x.type==='disease' && !wantsMedicine) score+=3;
    if(x.type==='medicine' && !wantsMedicine && wantsCondition) score-=3;
    return {x,score};
  }).sort((a,b)=>b.score-a.score);

  return scored[0]?.score>0 ? scored[0].x : null;
}
router.get('/health',(req,res)=>res.json({ok:true,service:'healthcare-ai-platform',aiConfigured:!!process.env.OPENAI_API_KEY}));
router.get('/medicines',(req,res)=>{
  const q=norm(req.query.q); let data=medicines;
  if(q)data=data.filter(m=>JSON.stringify(m).toLowerCase().includes(q));
  res.json({data});
});
router.get('/medicines/:id',(req,res)=>{const item=medicines.find(x=>x.id===req.params.id);if(!item)return res.status(404).json({error:'Medicine not found'});res.json({data:item});});
router.get('/diseases',(req,res)=>{
  const q=norm(req.query.q); let data=diseases;
  if(q)data=data.filter(d=>JSON.stringify(d).toLowerCase().includes(q));
  res.json({data});
});
router.get('/diseases/:id',(req,res)=>{const item=diseases.find(x=>x.id===req.params.id);if(!item)return res.status(404).json({error:'Condition not found'});res.json({data:item});});
router.get('/search',async(req,res)=>{
  const q=String(req.query.q||'').trim(); if(!q)return res.status(400).json({error:'Query required'});
  const local=[...medicines,...diseases].filter(x=>JSON.stringify(x).toLowerCase().includes(q.toLowerCase()));
  res.json({local});
});
router.post('/ai/chat',async(req,res)=>{
  try{
    const q=String(req.body?.query||'').trim(); const lang=langMap[req.body?.language]||'en';
    if(!q||q.length>4000)return res.status(400).json({error:'Please provide a valid query (max 4000 characters).'});
    const match=matchItem(q);
    const result=await answer(q,{match},lang);
    res.json(result);
  }catch(e){
    console.error(e);
    res.status(503).json({error:'AI service is unavailable. Add OPENAI_API_KEY for live AI, or ask about a catalogue medicine/condition for built-in educational answers.'});
  }
});
router.get('/sources/search',async(req,res)=>{try{const q=String(req.query.q||'').trim();if(!q)return res.status(400).json({error:'Query required'});res.json(await searchMedicalSources(q));}catch(e){res.status(502).json({error:'Reliable sources could not be reached right now.'});}});
module.exports=router;