const OpenAI = require('openai');
const {searchMedicalSources}=require('./search');

const LANG_NAMES={en:'English',hi:'Hindi',hinglish:'Hinglish',mr:'Marathi'};
const SYSTEM=`You are MedAware AI, an educational healthcare information assistant.
You are NOT a doctor. Do not diagnose, prescribe personalized treatment, or tell users to stop/change prescribed medicines.
Use the supplied local catalogue and retrieved authoritative sources. Never invent facts, prices or sources.
IMPORTANT LANGUAGE RULE: Answer ONLY in the requested language. If requested language is English, do not use Hindi, Marathi or Hinglish. If Hindi, use Hindi script. If Marathi, use Marathi script. If Hinglish, use natural Roman-script Hindi/English.
For a known medicine or one of the 15 known conditions, prioritize the supplied catalogue record and its exact basic-advice fields.
For disease questions, give: overview, common symptoms, free/basic advice, medicine categories only (not individualized prescriptions), when to see a doctor, warning signs, and sources.
For medicine questions, give: what it is, uses, common side effects, serious warnings, precautions, interactions, price availability, and sources.
If evidence is insufficient, say so. If an emergency is suggested, advise urgent professional/emergency care.
Keep the answer structured and readable.`;

function localFallback(query, context={}, lang='en'){
  const item=context.match;
  if(!item) return null;
  const t=item.translations?.[lang];
  const name=t?.name||item.name;
  if(item.type==='disease'){
    const summary=t?.summary||item.summary;
    const symptoms=t?.symptoms||item.symptoms||[];
    const advice=t?.advice||item.advice||[];
    const labels={
      en:['Overview','Common symptoms','Free basic advice','When to see a doctor','Warning signs'],
      hi:['परिचय','सामान्य लक्षण','मुफ्त सामान्य सलाह','डॉक्टर से कब मिलें','चेतावनी संकेत'],
      hinglish:['Overview','Common symptoms','Free basic advice','Doctor ko kab dikhayein','Warning signs'],
      mr:['आढावा','सामान्य लक्षणे','मोफत सामान्य सल्ला','डॉक्टरांना कधी भेटावे','धोक्याची चिन्हे']
    }[lang]||[];
    const bullets=a=>Array.isArray(a)?a.map(x=>`• ${x}`).join('\n'):a;
    return `${name}\n\n${labels[0]}\n${summary}\n\n${labels[1]}\n${bullets(symptoms)}\n\n${labels[2]}\n${advice}\n\n${labels[3]}\n${item.when_doctor}\n\n${labels[4]}\n${item.emergency}\n\n${lang==='hi'?'नोट: यह शैक्षणिक जानकारी है, व्यक्तिगत चिकित्सा सलाह नहीं है।':lang==='mr'?'टीप: ही शैक्षणिक माहिती आहे; वैयक्तिक वैद्यकीय सल्ला नाही.':lang==='hinglish'?'Note: Ye educational information hai, personal medical advice nahi.':'Note: This is educational information, not personal medical advice.'}`;
  }
  const labels={
    en:['What it is','Uses','Common side effects','Serious warnings','Precautions'],
    hi:['यह क्या है','उपयोग','सामान्य साइड इफेक्ट','गंभीर चेतावनी','सावधानियां'],
    hinglish:['What it is','Uses','Common side effects','Serious warnings','Precautions'],
    mr:['हे काय आहे','उपयोग','सामान्य दुष्परिणाम','गंभीर इशारे','काळजी']
  }[lang];
  return `${item.name}\n\n${labels[0]}\n${item.generic_name||item.name}\n\n${labels[1]}\n${(item.uses||[]).map(x=>'• '+x).join('\n')}\n\n${labels[2]}\n${(item.common_side_effects||[]).map(x=>'• '+x).join('\n')}\n\n${labels[3]}\n${(item.serious_side_effects||[]).map(x=>'• '+x).join('\n')}\n\n${labels[4]}\n${(item.precautions||[]).map(x=>'• '+x).join('\n')}\n\n${lang==='hi'?'नोट: यह शैक्षणिक जानकारी है, व्यक्तिगत चिकित्सा सलाह नहीं है।':lang==='mr'?'टीप: ही शैक्षणिक माहिती आहे; वैयक्तिक वैद्यकीय सल्ला नाही.':lang==='hinglish'?'Note: Ye educational information hai, personal medical advice nahi.':'Note: This is educational information, not personal medical advice.'}`;
}

async function answer(query, context={}, lang='en'){
  const retrieval=await searchMedicalSources(query);
  if(!process.env.OPENAI_API_KEY){
    const fallback=localFallback(query,context,lang);
    if(fallback) return {answer:fallback,sources:(context.match.sources||[]).map(url=>({title:'Authoritative source',url,score:1})),mode:'local-catalogue'};
    throw new Error('OPENAI_API_KEY is not configured.');
  }
  const client=new OpenAI({apiKey:process.env.OPENAI_API_KEY});
  const sourceText=retrieval.results.map((r,i)=>`SOURCE ${i+1}\nTITLE: ${r.title}\nURL: ${r.url}\nCONTENT: ${r.content}`).join('\n\n');
  const prompt=`REQUESTED LANGUAGE: ${LANG_NAMES[lang]||'English'}\nUSER QUERY:\n${query}\n\nLOCAL MATCH:\n${JSON.stringify(context.match||{},null,2)}\n\nRETRIEVED AUTHORITATIVE SOURCES:\n${sourceText||'No live sources were retrieved. Do not invent facts or sources.'}\n\nAnswer ONLY in ${LANG_NAMES[lang]||'English'}. If the user asks about a known condition, use ONLY that condition's local record for the condition-specific sections; do not substitute a medicine answer just because the condition can sometimes involve pain or fever. If the query names a condition, never return another condition's details.`;
  const response=await client.chat.completions.create({model:process.env.OPENAI_MODEL||'gpt-5',messages:[{role:'system',content:SYSTEM},{role:'user',content:prompt}],temperature:0.15});
  return {answer:response.choices[0]?.message?.content||'No answer was returned.',sources:retrieval.results.map(r=>({title:r.title,url:r.url,score:r.score})),mode:'live-ai'};
}
module.exports={answer};