async function searchMedicalSources(query) {
  if (!process.env.TAVILY_API_KEY) {
    return {results: [], warning: 'TAVILY_API_KEY is not configured. Live source retrieval is unavailable.'};
  }
  const response = await fetch('https://api.tavily.com/search', {
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body:JSON.stringify({
      api_key:process.env.TAVILY_API_KEY,
      query,
      search_depth:'advanced',
      max_results:6,
      include_answer:false,
      include_raw_content:false,
      include_domains:[
        'who.int','nhs.uk','medlineplus.gov','fda.gov','pubmed.ncbi.nlm.nih.gov'
      ]
    })
  });
  if (!response.ok) throw new Error(`Search provider error: ${response.status}`);
  const data=await response.json();
  return {results:(data.results||[]).map(x=>({title:x.title,url:x.url,content:x.content,score:x.score}))};
}
module.exports={searchMedicalSources};
